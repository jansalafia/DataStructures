

public interface YourStack {
	public void push (Integer i);
	public Integer pop();
	public Integer size();
}
